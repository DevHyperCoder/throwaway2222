# wap to store emp data in a stack impl list


s = []

def push():
	emid = int(input("Enter id: "))
	emname = input("Enter name: ")
	emsal = int(input("Enter sal: "))
	s.append([emid,emname,emsal])


def pop():
	if len(s) == 0:
		print("Underflow")
		return
	emp = s.pop()
	emid = emp[0]
	emname = emp[1]
	emsal =  emp[2]

	print("Id: ",emid)
	print("Name: ",emname)
	print("Sal: ",emsal)

push()
push()
pop()
pop()
pop()
