import pickle
import os

def writerecord():
	rollno = int(input("Enter roll: "))
	name = input("Enter name: ")
	mark = int(input("Enter marks: "))
	
	with open("stu.dat","ab") as f:
		pickle.dump([rollno,name,mark],f)

def remove():
	f = open("stu.dat","rb")
	new_f = open("stu_backup.dat","wb")
	
	try:
		roll= int(input("Enter roll to delete: "))
		while True:
			orig = f.tell()
			stu = pickle.load(f)
			if stu[0] == roll:
				continue
			pickle.dump(stu,new_f)
	except EOFError:
		pass
	

	os.remove("stu.dat")
	os.rename("stu_backup.dat","stu.dat")

	
while True:
	ch = input("Enter choice: (1): add (2): remove")
	if ch == "1":
		writerecord()
	if ch == "2":
		remove()
	
