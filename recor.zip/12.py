import pickle

def add():
	eidno = int(input("Enter eid: "))
	ename = input("Enter ename: ")
	esal = int(input("Enter esals: "))
	
	with open("emp.dat","ab") as f:
		pickle.dump([eidno,ename,esal],f)

def updateesal():
	with open("emp.dat","rb+") as f:
		try:
			found = False
			eid= int(input("Enter eid to update: "))
			while True:
				orig = f.tell()
				emp = pickle.load(f)
				if emp[0] == eid:
					# update
					f.seek(orig)
					emp[2] = int(input("Enter new esal: "))
					found= True
					pickle.dump(emp,f)
		except EOFError:
			pass
		if not found:
			print("Not found")
		

	
while True:
	ch = input("Enter choice: (1): add (2): update")
	if ch == "1":
		add()
	if ch == "2":
		updateesal()
	
