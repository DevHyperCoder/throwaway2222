import pickle

def add():
	
	with open("stu.dat","wb") as f:
		for i in range(4):
			rollno = int(input("Enter roll: "))
			name = input("Enter name: ")
			mark = int(input("Enter marks: "))
			pickle.dump([rollno,name,mark],f)

def updatemark():
	with open("stu.dat","rb+") as f:
		try:
			found = False
			roll= int(input("Enter roll to update: "))
			while True:
				orig = f.tell()
				stu = pickle.load(f)
				if stu[0] == roll:
					# update
					f.seek(orig)
					stu[2] = int(input("Enter new mark: "))
					found= True
					pickle.dump(stu,f)
		except EOFError:
			pass
		if not found:
			print("Not found")
		

	
while True:
	ch = input("Enter choice: (1): add (2): update")
	if ch == "1":
		add()
	if ch == "2":
		updatemark()
	
