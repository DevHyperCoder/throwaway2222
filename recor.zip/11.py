import pickle
import os

def writerecord():
	enono = int(input("Enter eno: "))
	ename = input("Enter ename: ")
	esal = int(input("Enter esals: "))
	
	with open("emp.dat","ab") as f:
		pickle.dump([enono,ename,esal],f)

def remove():
	f = open("emp.dat","rb")
	new_f = open("emp_backup.dat","wb")
	
	try:
		eno= int(input("Enter eno to delete: "))
		while True:
			orig = f.tell()
			emp = pickle.load(f)
			if emp[0] == eno:
				continue
			pickle.dump(emp,new_f)
	except EOFError:
		pass
	

	os.remove("emp.dat")
	os.reename("emp_backup.dat","emp.dat")

	
while True:
	ch = input("Enter choice: (1): add (2): remove")
	if ch == "1":
		writerecord()
	if ch == "2":
		remove()
	
